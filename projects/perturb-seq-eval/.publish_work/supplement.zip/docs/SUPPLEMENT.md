# Supplementary Materials — Reproduction and Findings

Companion to [`SUPPLEMENT_DESIGN.md`](SUPPLEMENT_DESIGN.md). This document
is the **reviewer-facing** artifact for the full Modal reproduction:
every number, figure, and decision is regenerable from shipped code.

Status: comprehensive Modal run complete on 2026-04-21; **revision pass
with bootstrap CIs, cumulative regret, and numerical γ_T landed
2026-04-22** (addresses MC1 + mc5 + mc8 + mc9 from
[`REVIEWER_CRITIQUE.md`](REVIEWER_CRITIQUE.md)). Adamson pilot
reproduction numbers are real (A10G GPU workers for the grid fill);
probe signatures on Adamson are **simulated** from a
difficulty-indexed DGP rather than harvested from a live agent trace
(MC3a — see §5.3). Budget spend tracked: image rebuild + E2-synthetic +
E2-Adamson + E3 stack + figures ≪ the $30 ceiling; revision pass adds
zero Modal cost because it reuses the cached grids.

## 1. Environment

| Component | Version |
|---|---|
| Python | 3.11 on Modal, ≥3.10 locally |
| Modal | client 1.4.2 |
| Poetry | ≥ 2.0 |
| NumPy | ≥ 1.26 |
| PyTorch (`scgpt_small`) | 2.2+ (Modal image; optional locally via `--with scgpt`) |
| Plotly / Kaleido | 5.22 / 0.2.1 (older kaleido pinned so no Chrome install needed) |

## 2. Data

- **Synthetic DGP**: `perturb_eval.experiments.e2_grid_fill._build_synthetic_dataset`, seeded per `(task, seed)` pair.
- **Adamson 2016 pilot**: 5 768 K562 cells × 35 635 genes × 9 perturbations. The scPerturb Zenodo redistribution of GEO GSE90546 (record 13350497). Fetched via `scripts/fetch_adamson.py`, uploaded to the `perturb-eval-data` Modal volume at `/adamson/Adamson2016_pilot.h5ad`. In the supplement run we pre-filtered to the 7 targeted-knockdown perturbations (BHLHE40, CREB1, DDIT3, EP300, SNAI1, SPI1, ZNF326), downsampled to 400 cells per perturbation, and kept the top 2 000 highly-variable genes.

## 3. Installation

```bash
git clone <this repo>
cd projects/perturb-seq-eval
poetry install --with dev,research,paper --no-root
poetry run pip install -e .           # editable install for the src/ tree

# Only needed if running the scgpt_small backbone locally:
poetry install --with scgpt

# Only needed for Modal submission:
pip install modal && modal setup
```

## 4. Verification ladder

| Rung | Command | Wall time | Cost |
|---|---|---|---|
| 4.1 Unit tests | `poetry run pytest -q` | ≤ 0.3 s | $0 |
| 4.2 Full local dry-run (synthetic) | `poetry run python scripts/local/full_local_dry_run.py` | ~80 s | $0 |
| 4.3 Local E3b calibration check | `poetry run python scripts/local/e3b_task_conditional.py` | ~1 s | $0 |
| 4.4 **Modal full comprehensive run** (this supplement) | `modal volume put perturb-eval-data data/Adamson2016_pilot.h5ad /adamson/Adamson2016_pilot.h5ad && modal deploy scripts/modal/app.py && modal run scripts/modal/app.py::entrypoint --step all` | ~45 min wall clock | ≤ $30 (actual ≪ ceiling) |
| 4.5 Post-run artifact download | `modal volume get perturb-eval-data /results ./artifacts/modal_run/ && modal volume get perturb-eval-data /figures ./artifacts/modal_run/` | seconds | $0 |

Current status (all rungs passed): `92 passed in 0.21s`, full pipeline complete under budget.

## 5. Results

All numbers below come from `artifacts/modal_run/` (committed alongside this file). Figures are Plotly PDF + HTML pairs in `artifacts/modal_run/figures/`.

### 5.1 E1 — Metric overlap (n = 5 000 synthetic traces on Modal)

The pre-registered drop rule (Spearman ≥ 0.95 with historical counterpart) is applied to each new metric.

| Historical | New | Spearman ρ | Keep? | Rationale |
|---|---|---|---|---|
| ACE_H (softmax entropy) | ACE_D (simplex entropy) | **0.940** | ✅ keep both | Below 0.95 — distinct on concentrated-confidence inputs. |
| CSD (variance) | CSD★ (excess-over-median) | **0.519** | ✅ keep both | Low correlation; genuinely different disagreement topologies. |
| TDI (linear) | TDI₂ (+ pairwise interactions) | **0.960** | ❌ drop TDI₂ | Above 0.95 — interactions don't add signal at their current coefficients. |

![Figure 1 — Spearman heatmap across all 8 metrics](../artifacts/modal_run/figures/fig1_metric_heatmap.png)

*Figure 1. Spearman rank correlation across the 8 metric signals on 5 000 synthetic traces. Key non-redundancy pairs: ACE_H–ACE_D (ρ = 0.94), CSD–CSD★ (ρ = 0.52), TDI–TDI₂ (ρ = 0.96, triggers drop). Source: `artifacts/modal_run/figures/fig1_metric_heatmap.{png,pdf,html}`.*

Secondary signals (same 8×8 matrix, `artifacts/modal_run/results/e1_overlap.json`):

- ρ(WFR, TDI) ≈ +0.64 — winner-flip rate drives most of TDI in this DGP.
- ρ(ΔC, TDI) ≈ −0.46 — convergence speed enters TDI inversely, as designed.
- ρ(ACE_H, WFR) ≈ −0.30 — flat confidences and winner churn weakly anti-correlate.

### 5.2 E2 — Offline grid fill on both DGPs

Full Φ = {3, 4, 5 agents} × {1, 2, 3 rounds} × {linear, mlp, scgpt_small backbones} = **27 configurations**.

| Grid | Tasks | Seeds | Cells | MSD range | Source |
|---|---|---|---|---|---|
| Synthetic (large) | 8 | 5 | **1 080** | [0.0042, 0.52] | `e2_grid_synthetic.jsonl` |
| **Adamson real data** | 7 | 3 | **567** | [0.0039, 0.28] | `e2_grid_adamson.jsonl` |

Mean MSD per backbone:

| Backbone | Synthetic (n=1 080) | Adamson real (n=567) |
|---|---|---|
| linear       | **0.014** | 0.059 |
| mlp          | 0.233     | 0.059 |
| scgpt_small  | 0.236     | 0.059 |

![Figure 5 — Per-backbone MSD across both grids](../artifacts/modal_run/figures/fig5_backbone_msd.png)

*Figure 5. Held-out MSD boxplot by backbone, grouped by source. On synthetic data the linear backbone dominates by an order of magnitude (matches the DGP's inductive bias). On real Adamson data the three backbones are statistically tied in mean, but the winners-per-task distribution (next table) favours scgpt_small. Source: `fig5_backbone_msd.{png,pdf,html}`.*

**Best (phi, task) on Adamson** — the per-task winners:

| Task | Best phi | MSD |
|---|---|---|
| CREB1   | `a5_r2_scgpt_small` | **0.00388** |
| DDIT3   | `a3_r3_mlp`         | 0.00516 |
| EP300   | `a3_r1_mlp`         | 0.03511 |
| SNAI1   | `a3_r1_scgpt_small` | 0.05215 |
| ZNF326  | `a3_r1_scgpt_small` | 0.05823 |
| BHLHE40 | `a3_r2_scgpt_small` | 0.07025 |
| SPI1    | `a4_r1_scgpt_small` | 0.15732 |

**Per-seed decomposition of "winners" on Adamson** (response to MC2 in
[`REVIEWER_CRITIQUE.md`](REVIEWER_CRITIQUE.md)):

| Seed | `scgpt_small` wins | `mlp` wins | `linear` wins |
|---|---|---|---|
| 2026 | 5 | 1 | 1 |
| 2027 | 4 | 3 | 0 |
| 2028 | 3 | 2 | 2 |

The "5/7 wins" figure is an artefact of seed 2026 only; under seed 2028
`scgpt_small` drops to 3/7 and `linear` appears twice. Per-task
mean MSDs for the three backbones overlap within ±1 seed-standard-error
on five of seven tasks (BHLHE40, CREB1, DDIT3, EP300, ZNF326).

**Honest reframing of the real-data backbone result.**

> On the Adamson pilot the three backbones are statistically
> indistinguishable per task (per-seed MSDs overlap within ±σ on
> 5/7 tasks). The mean MSD difference between the best and worst
> backbone per task ranges from 0.0004 to 0.010. **No single backbone
> dominates real Adamson**, in contrast to the synthetic DGP where the
> linear backbone wins every task by ≈ 10×.
>
> What *does* transfer from synthetic → Adamson is the *loss* of linear
> dominance: whatever inductive bias the linear "target-gene-dip"
> heuristic exploits on synthetic data is swamped by the transcriptional
> complexity of real K562 UPR responses. Reading this as "scgpt_small
> wins 5/7" would be statistically unsupported.

### 5.3 E3 — Optimizer comparison on both grids

30 iterations × 20 seeds per task, three optimizers.

#### Synthetic (shared-optimum regime)

Bootstrap 95 % CIs over (task × seed) with n_boot = 2 000:

| Optimizer | Final MSD (mean) | Final MSD 95 % CI | Final regret (mean) |
|---|---|---|---|
| random | 0.00721 | [0.00665, 0.00776] | 0.00026 |
| cma_es (one+λ ES) | 0.00732 | [0.00678, 0.00787] | 0.00037 |
| contextual_gp | **0.00713** | [0.00660, 0.00769] | **0.00018** |

All three CIs overlap; the nominal "win" for contextual GP sits well
inside the noise. Numerical γ_T at T = 30 on this regime's factor
kernel = **56.17** (greedy estimate via Krause, Singh & Guestrin 2008).

![Figure 2 — E3 synthetic trajectories with CIs](../artifacts/modal_run/figures/fig2_e3_synthetic.png)

*Figure 2. Synthetic shared-optimum DGP. All three optimizers converge
to the same global minimum; CIs overlap completely; contextual GP has
the lowest point-estimate regret but is not statistically separated
from CMA-ES or random. **This is the correct falsification of Claim A
on shared-optimum DGPs** — the framework reports "no advantage" when
the probe cannot route, exactly as designed.*

#### Adamson real data

> **Probe disclosure (MC3a in [`REVIEWER_CRITIQUE.md`](REVIEWER_CRITIQUE.md)).**
> The probe signatures `x_T` fed to the contextual GP on real Adamson
> tasks are **simulated** from a deterministic difficulty-indexed
> distribution (`_probe_for_task()` in
> [`scripts/modal/app.py`](../scripts/modal/app.py) and, for the
> revision rerun, `synth_probe_contexts()` in
> [`scripts/local/bootstrap_and_analyze.py`](../scripts/local/bootstrap_and_analyze.py)).
> They were **not** harvested from a live CellForge orchestrator run on
> these perturbations. The numbers below therefore report "contextual GP
> on real-Adamson MSDs + simulated probe signatures" — a lower bound on
> what a live trace-collection run would achieve. Closing this gap
> (MC3b) is tracked as future work in §7; the infrastructure is wired
> through [`scripts/modal/collect_traces.py`](../scripts/modal/collect_traces.py).

Bootstrap 95 % CIs over (task × seed) with n_boot = 2 000:

| Optimizer | Final MSD (mean) | Final MSD 95 % CI | Final regret (mean) | CI overlap with contextual GP? |
|---|---|---|---|---|
| random | 0.05605 | **[0.04842, 0.06423]** | 0.00000 | ✅ overlaps |
| cma_es (one+λ ES) | 0.05871 | **[0.05022, 0.06793]** | 0.00266 | ✅ overlaps |
| contextual_gp | 0.05720 | **[0.04904, 0.06550]** | 0.00115 | — |

![Figure 3 — E3 Adamson trajectories with CIs](../artifacts/modal_run/figures/fig3_e3_adamson.png)

*Figure 3. On real Adamson perturbations the three optimizers' 95 % CIs
on final MSD **overlap substantially**. The previously-quoted 2.6 %
contextual-vs-CMA-ES edge is inside the noise floor (CIs span
~0.015 MSD; the gap to CMA-ES is 0.0015). Honest reading: contextual
GP, CMA-ES (one+λ ES), and random are statistically indistinguishable
on Adamson pilot at n_tasks = 7, n_seeds = 20. The infrastructure does
not produce a real-data routing advantage under the current probe
simulation — this matches what we'd expect when probe informativeness
is low and Φ is small enough that coverage-based random sampling is
strong.*

Cumulative regret per iteration is also now emitted alongside AULC
(see mc5 in the deviation log). On Adamson, contextual GP's final
cumulative regret is 0.00115 (best of the three), but the three
trajectories remain within each other's CI bands throughout.

### 5.4 E3b — Task-conditional calibration (infrastructure validation)

When the DGP encodes explicit task-conditional optima (easy tasks prefer small configs, hard tasks prefer large `scgpt_small` configs), the contextual GP should dominate. Budget: 30 iterations × 20 seeds × 8 tasks, CPU-only.

Bootstrap 95 % CIs over (task × seed) with n_boot = 2 000:

| Optimizer | Final MSD (mean) | Final MSD 95 % CI | Final regret (mean) | CI overlap with contextual GP? |
|---|---|---|---|---|
| random | 0.00683 | [0.00456, 0.00933] | 0.00683 | ✅ overlaps |
| cma_es (one+λ ES) | 0.07500 | **[0.06375, 0.08625]** | 0.07500 | ❌ **non-overlapping** |
| contextual_gp | 0.00989 | [0.00535, 0.01535] | 0.00989 | — |

Numerical γ_T at T = 30 on the task-conditional kernel = **53.97**.

![Figure 4 — E3b calibration check with CIs](../artifacts/modal_run/figures/fig4_e3b_task_conditional.png)

*Figure 4. Task-conditional synthetic DGP. **Contextual GP vs
CMA-ES CIs do not overlap** — the separation is statistically
significant at the 95 % level. This is the cleanest positive result in
the supplement: when the DGP has genuine routable structure,
contextual-BO's advantage is both large in magnitude (≈ 7.6× on
point estimates) and survives the 2 000-bootstrap noise floor. Random
is on the contextual-GP side of the gap — it matches contextual GP on
final MSD because |Φ| = 27 is small enough that random coverage
eventually finds each task's optimum, though it takes many iterations
to do so (random's early iterations are ~ 14× worse than contextual
GP's).*

## 6. Discussion

### 6.1 The three regimes, side-by-side

With the revision-pass CIs in place, the three regimes separate into a
simple, honest pattern:

| Regime | Probe informativeness | Contextual vs CMA-ES CI | γ_T (T=30) | Interpretation |
|---|---|---|---|---|
| **Synthetic shared-optimum** (E3) | none (every task same optimum) | overlaps | 56.17 | Correct falsification: framework reports "no advantage" when probe cannot route. |
| **Real Adamson pilot** (E3-Adamson) | simulated; weak by design | **overlaps** | 63.10 | Statistically indistinguishable. The previously-claimed 2.6 % edge is inside the noise floor. |
| **Synthetic task-conditional** (E3b) | strong (explicit routing by task family) | **non-overlapping** | 53.97 | Only regime where contextual GP's advantage over CMA-ES is statistically significant at 95 %. |

Reading across the table honestly:

- **Shared-optimum** — all three optimizer CIs overlap; the framework correctly says "no signal".
- **Real Adamson** — same: all three CIs overlap. With n_tasks = 7 and probe signatures that are themselves simulated, the data cannot support the stronger claim ("contextual GP routes on real Adamson") that an earlier draft implied. The contribution on real data is the **backbone-axis** behaviour in §5.2 (linear's synthetic dominance fails to transfer), not an optimizer-level advantage.
- **Task-conditional synthetic** — contextual GP ≠ CMA-ES at 95 %. This is the only regime where a statistically-significant optimizer advantage is supported by the data.

Net: **the framework is internally consistent — it reports "no advantage"
when there is none to exploit, and a significant advantage only on a
DGP where genuine task-conditional structure exists.** That is itself a
publishable result. What it does *not* (yet) show is that real
perturb-seq data has enough task-conditional structure to let
contextual BO beat non-contextual alternatives with statistical
significance. Closing that gap requires either more tasks (Norman 2019,
MC4) or real probe-trace collection (MC3b) — both queued in §7 below.

### 6.2 The Adamson backbone result (revised per MC2)

On synthetic data, the linear backbone matches the DGP's inductive bias exactly (target-gene knockdown → dip at that gene) and wins 100 % of tasks by ≈ 10×.

On real Adamson data the aggregate-across-seeds winner-count was previously quoted as "`scgpt_small` 5 / `mlp` 2 / `linear` 0", but the per-seed decomposition in §5.2 shows that number is **unstable**: under seed 2028 `scgpt_small` drops to 3/7 and `linear` reappears on 2 tasks. Per-task MSD spreads of all three backbones overlap within ±1 seed-SE on 5 of 7 tasks.

The **defensible** statement is therefore weaker and more interesting:

> Linear's synthetic-DGP dominance does not transfer to real Adamson data. All three backbones are statistically indistinguishable per task; none wins with 95 %-level confidence. What we observe on real data is the *absence* of the inductive-bias advantage, not the presence of a transformer-specific one.

This is still a useful empirical observation — it tells us that the
backbone axis of Φ is **genuinely non-trivial** on real data (unlike on
the synthetic DGP where linear trivially wins), which is the minimum
requirement for a hyperparameter-tuning paper to have a non-degenerate
backbone dimension. It is not, however, evidence for a specific
architectural advantage of the 2.1 M-param `scgpt_small`. The original
prose ("wins 5/7 tasks") has been retracted.

A genuine architectural story on Adamson-class data would likely
require (a) the full scGPT pretrained weights, (b) the full Norman 2019
dataset (MC4), or (c) CPA/GEARS-style perturbation-embedding modules
— none are in this supplement.

### 6.3 Why all three CIs overlap on Adamson — honest analysis (revised per MC1)

With bootstrap CIs in hand (see §5.3 table), the data are now clear:
the three optimizers' final-MSD CIs on Adamson span a ~0.015 MSD
window and the pairwise gaps are ≤ 0.003 MSD. **No optimizer wins
with statistical significance.** The previously-claimed contextual-GP
vs CMA-ES edge (2.6 % point estimate) is 5–10× smaller than the
bootstrap half-width; there is no evidence that probe-simulated
routing beats a stationary-optimum ES on this dataset at current
n_tasks = 7 / n_seeds = 20.

Three non-exclusive explanations, any of which would predict the
observed tie:

1. **Probe simulation.** The probes are sampled from a difficulty-keyed DGP, not harvested from a live orchestrator. Whatever routing advantage a real probe might carry is absent by construction. This is MC3b in [`REVIEWER_CRITIQUE.md`](REVIEWER_CRITIQUE.md).
2. **Shallow landscape.** On Adamson, per-task MSD varies < 4× between best and worst Φ-point for most tasks (§5.2); in a shallow landscape almost any search strategy is adequate.
3. **Small n_tasks.** Seven tasks × 20 seeds gives ~140 observations per optimizer, but the task-to-task variance dominates — the CIs are limited by n_tasks, not n_seeds. MC4 (Norman 2019 grid, ~200 tasks) is the remedy.

The defensible Adamson story is therefore the **backbone-axis
observation** (§6.2, linear doesn't dominate) and the **infrastructure
consistency** (the framework correctly reports a tie when a tie is what
the data contains) — not an optimizer-level advantage.

### 6.4 Information-gain interpretation of the three regimes — now with numerical γ_T (mc8)

The Krause & Ong 2011 regret bound $R_T = O(\sqrt{T \gamma_T})$ depends
on the **maximum information gain** $\gamma_T$ of the factored kernel
over (Φ, X). Previously qualitative; the revision pass computes γ_T
numerically for each regime via the greedy
maximum-info-gain algorithm of Krause, Singh & Guestrin 2008 §5.1
(submodular greedy → (1−1/e)-optimal):

| Regime | γ_T at T=30 | Contextual-GP final-MSD CI width |
|---|---|---|
| Synthetic shared-optimum | **56.17** | 0.00109 |
| Adamson real (simulated probes) | **63.10** | 0.01646 |
| Task-conditional synthetic | **53.97** | 0.01000 |

Three honest observations:

1. **γ_T is a property of the kernel, not the DGP.** Adamson has the highest γ_T in our setup because the context-kernel sees more spread in the probe signature values, not because probes are more informative. An uninformative probe with wide support can still have large γ_T.
2. **Bound is conservative, not predictive.** The absolute magnitude of the regret bound $O(\sqrt{T γ_T})$ is 41–43 across regimes, while observed final regret is ≤ 0.01 in every regime — i.e. the bound is loose by 3+ orders of magnitude. Use γ_T as a *sanity check* on the kernel ("is exact GP fitting cheap and well-posed?") rather than as a performance predictor.
3. **What actually distinguishes the regimes is the shape of the objective landscape in Φ**, not γ_T. This is the observation encoded in §6.1's CI-overlap column.

Numerical γ_T values and the greedy computation live in
[`scripts/local/bootstrap_and_analyze.py::max_information_gain`](../scripts/local/bootstrap_and_analyze.py).

### 6.5 The metric redesign survived a harder test

At n = 5 000 the Spearman estimates tighten (standard error ~0.014 vs ~0.022 at n = 2 000). The decisions hold:

- ACE_D: ρ(ACE_H, ACE_D) = 0.940 → below threshold, keep. ACE_D captures inequality on concentrated-confidence inputs (0.00) that softmax-based ACE_H compresses to ~0.85.
- CSD★: ρ(CSD, CSD★) = 0.519 → far below threshold, keep. CSD is a bimodal-disagreement signal; CSD★ is an outlier-severity signal. They are genuinely different.
- TDI₂: ρ(TDI, TDI₂) = 0.960 → above threshold, drop. The pairwise interactions at their current coefficients don't encode separable signal on this DGP. The library retains the code path; the pre-registered rule requires us to drop the metric from the paper until a real-data ridge fit or a non-linear surrogate recovers the missing interactions.

## 7. Conclusion (revised 2026-04-22 per MC1–MC3 in REVIEWER_CRITIQUE.md)

1. **The metric design is sound.** ACE_D and CSD★ are additive to the historical metric set at the 0.95-Spearman-drop gate; TDI₂ is correctly removed. Pre-registered rules held.
2. **The infrastructure is internally consistent across three regimes.** With bootstrap CIs:
   - synthetic shared-optimum → all three optimizer CIs overlap (correct falsification, no advantage to be had);
   - real Adamson (simulated probes) → **all three CIs overlap** (honest tie; previously-quoted 2.6 % edge was inside the noise floor);
   - task-conditional synthetic → **contextual GP vs CMA-ES CIs do not overlap** (statistically significant, the only regime where a contextual advantage is supported by the data).
3. **Backbone axis observation on real data.** Linear's synthetic-DGP dominance does not transfer: on Adamson all three backbones are statistically indistinguishable per task within ±1 seed-SE on 5/7 tasks. The previously-claimed "scgpt_small wins 5/7" was an artefact of one seed and has been retracted; the defensible statement is that the backbone axis is **non-trivial** on real data, not that any one backbone wins.
4. **Probe disclosure.** Probe signatures on Adamson are simulated, not harvested from a live orchestrator. What we've shown is that the infrastructure works (E3 + E3b + Adamson); what we have not yet shown is that real probe traces on real perturbations route well. That gap is MC3b and is queued.
5. **Numerical γ_T per regime** (mc8): synthetic 56.17, Adamson 63.10, task-conditional 53.97. γ_T is a property of the kernel, not the DGP, and is best read as a sanity check on the GP itself rather than a performance predictor.
6. **Budget.** Total Modal spend ≪ $30 ceiling; the revision pass added $0 because it reuses the cached grids.

### Open empirical questions (ranked by what they would unlock)

1. **MC3b — Live probe collection.** Run the CellForge orchestrator once per Adamson task, harvest the real round-0 probe, rerun E3-Adamson. This is the single change that would convert §5.3 from "infrastructure on real MSDs + simulated probes" into "infrastructure + real probes on real data". Cost: ≈ 1 engineer-day of wiring on the existing [`scripts/modal/collect_traces.py`](../scripts/modal/collect_traces.py) skeleton, $0 on the OpenRouter free tier. **Highest priority.**
2. **MC4 — Larger task count via Norman 2019.** ≈ 200 perturbations, genuine combinatorial signals. CI widths are dominated by n_tasks = 7 at present; going to Norman should shrink them by ~√(200/7) ≈ 5×. Cost: ~$5–10 on Modal A10G.
3. **Pretraining `scgpt_small`.** The current from-scratch 2.1 M-param transformer has no access to the scGPT pretraining corpus. Pretraining on 33 M cells would plausibly restore a real transformer-specific backbone advantage on Adamson. Cost: 1 day + $20 Modal, out of current budget.
4. **mc10 — Fair-parameter backbone comparison.** `scgpt_small` currently scales its embedding vocab to match HVG count, so synthetic (40 genes) and Adamson (2 000) are run with 13× different parameter counts. Fix `n_genes_used = 2 000` on both grids and rerun E2-synthetic.

## 8. Raw artifacts index (everything committed to `artifacts/modal_run/`)

| File | Content |
|---|---|
| `results/e1_overlap.json` | 8×8 Spearman matrix at n = 5 000 + drop decisions |
| `results/e2_grid_synthetic.jsonl` | 1 080 synthetic grid cells |
| `results/e2_grid_adamson.jsonl` | 567 Adamson-real grid cells |
| `results/e3_synthetic.json` | Optimizer trajectories, synthetic shared-optimum |
| `results/e3_adamson.json` | Optimizer trajectories, Adamson real data |
| `results/e3b_task_conditional.json` | Optimizer trajectories, synthetic calibration |
| `figures/fig{1,2,3,4,5}_*.png` | Plotly PNGs — inline-rendered in markdown viewers |
| `figures/fig{1,2,3,4,5}_*.pdf` | Print-resolution PDFs for LaTeX inclusion |
| `figures/fig{1,2,3,4,5}_*.html` | Interactive Plotly HTMLs (same data, hover/zoom) |

Every file is plain JSON/JSONL. Inspect with `jq`; plot with any notebook.

## 9. Deviation log

| Date | Change | Rationale |
|---|---|---|
| 2026-04-20 | CSD★ defined as `(max − median) / (1 − median + ε)`. | Matches thesis prose, bounded [0,1], rank-stable. |
| 2026-04-20 | Contextual GP uses numpy-only A&S erf instead of scipy. | Keeps the core optimizer path dependency-free. |
| 2026-04-20 | (1+λ)-ES substitutes full CMA-ES. | Dependency-free; enough for the non-contextual baseline. |
| 2026-04-20 | TDI₂ dropped from headline metrics. | Pre-registered Spearman ≥ 0.95 rule fired. |
| 2026-04-20 | E3b calibration added. | Needed to show contextual advantage is not vacuous. |
| 2026-04-21 | Modal image pins `kaleido==0.2.1` and `plotly<6.0`. | Newer kaleido requires `plotly_get_chrome`, impractical in a slim container. |
| 2026-04-21 | `scgpt_small` embedding grows vocab to match `n_genes` (up from `max_genes=1024`). | Adamson's 2 000-HVG vocab overflows the default; now guards the index-out-of-range path. |
| 2026-04-21 | `PROJECT_DIR_HOST = Path(__file__).parents[2]` made container-safe. | Container has no `parents[2]`; IndexError crashed early runs. |
| 2026-04-22 | `OptimizerTrajectory` dataclass gained `per_seed_trajectories` and `cum_regret_per_iter` fields. | Required for MC1 bootstrap CIs and mc5 cumulative-regret reporting. Backwards-compatible (new fields default to `()`). |
| 2026-04-22 | `CMAESOptimizer` renamed to `OnePlusLambdaES` with alias. | mc7: the implementation is Rechenberg (1+λ)-ES with one-fifth-success, not CMA-ES with rank-μ covariance adaptation. Registry dispatches on either name. |
| 2026-04-22 | Added `scripts/local/bootstrap_and_analyze.py`. | MC1 (bootstrap 95 % CIs), mc5 (cumulative regret), mc8 (numerical γ_T via Krause–Singh–Guestrin 2008 greedy max-info-gain). |
| 2026-04-22 | Added `scripts/local/render_figures_revised.py` (Wong palette + CI bands). | mc9 colourblind-safe palette; visual CI bands on Figs 2/3/4. |
| 2026-04-22 | §5.2 / §6.2 / §5.3 / §6.3 / §7 reframed per MC1 / MC2 / MC3a. | Retracted "scgpt_small wins 5/7" and "contextual GP beats CMA-ES by 2.6 % on Adamson" claims; disclosed probe-simulation confound in §5.3 preamble. |
| 2026-04-22 | §6.4 γ_T bound-interpretation now quotes numerical γ_T values per regime. | mc8: qualitative metaphor replaced with three real numbers + an explicit caveat about what γ_T does and doesn't predict. |

## 10. License

Code under Apache-2.0. Adamson pilot redistribution is CC-BY-4.0 (Zenodo record 13350497). scPerturb repackaging preserves the Adamson 2016 original data licence.
