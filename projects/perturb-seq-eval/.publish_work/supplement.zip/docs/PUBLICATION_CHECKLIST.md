# Publication Checklist & Repo Organization

> Roadmap from "supplement ready" to "submission out." Parallel checklist
> to [`REVIEWER_CRITIQUE.md`](REVIEWER_CRITIQUE.md); read that file first
> for blocker-level revision requirements.

## 0. Current state (2026-04-21)

| Deliverable | State | Location |
|---|---|---|
| Thesis | ✅ drafted | [`docs/THESIS.md`](THESIS.md) |
| Engineering design | ✅ drafted | [`docs/DESIGN.md`](DESIGN.md) |
| Supplement design | ✅ drafted | [`docs/SUPPLEMENT_DESIGN.md`](SUPPLEMENT_DESIGN.md) |
| Supplement results | ✅ populated with real Modal numbers | [`docs/SUPPLEMENT.md`](SUPPLEMENT.md) |
| Reviewer critique | ✅ written | [`docs/REVIEWER_CRITIQUE.md`](REVIEWER_CRITIQUE.md) |
| Paper LaTeX | ✅ prior version renders | [`paper/paper.pdf`](../paper/paper.pdf) |
| Code + tests | ✅ 92/92 pytest green | [`src/`](../src/), [`tests/`](../tests/) |
| Modal artifacts | ✅ downloaded | [`artifacts/modal_run/`](../artifacts/modal_run/) |
| Figures (PNG + PDF + HTML) | ✅ generated | [`artifacts/modal_run/figures/`](../artifacts/modal_run/figures/) |

## 1. Blocker revisions (must land before submission)

From [`REVIEWER_CRITIQUE.md`](REVIEWER_CRITIQUE.md) §MC1–MC3:

- [ ] **MC1** — emit per-seed E3 trajectories + bootstrap 95 % CIs on all headline numbers
  - add `n_seeds_out` path to `run_e3_optimizer_comparison` that stores the full seed × iter tensor
  - `scripts/local/bootstrap_ci.py` that reads the tensor, emits a table of `(optimizer, mean, ci_low, ci_high)`
  - regen Figs 2, 3, 4 with shaded error bands
- [ ] **MC2** — reframe §5.2 / §6.2 to acknowledge backbone ties on Adamson within seed variance; retract the "5/7 wins" headline
- [ ] **MC3** — choose one:
  - [ ] (a) disclose probe-simulation confound in abstract and §5.3 preamble (cheap, 2 h)
  - [ ] (b) run real CellForge traces on each Adamson task, rerun E3-Adamson with real probes (1 day, ≈$0 on OpenRouter free tier)
  - Decision owed by author before submission.

## 2. Major revisions (strong-accept upgrade)

- [ ] **MC4** — add Norman 2019 grid OR defer-explicitly with a single paragraph in §7 Open Empirical Questions
- [ ] **mc5** — replace AULC with cumulative regret Σ(y_t − y_min) as the headline optimizer metric
- [ ] **mc10** — fix `scgpt_small` vocab to a constant 2 000 across synthetic + Adamson grids; rerun E2-synthetic (Modal cost ≈ $2)

## 3. Polish (round-out)

- [ ] **mc6** — tone down backbone-dominance prose
- [ ] **mc7** — rename `cma_es` → `one_plus_lambda_es` in code + docs (or install the `cma` package and dispatch to real CMA-ES when available)
- [ ] **mc8** — compute γ_T numerically OR delete the bound-interpretation paragraph
- [ ] **mc9** — switch Plotly trajectory lines to the Wong palette (`#E69F00, #56B4E9, #009E73`)

## 4. Publication targets — in priority order

### 4.1 Preprint + MassGen contribution (immediate)

- [ ] upload SUPPLEMENT.md + code + artifacts to bioRxiv and arXiv cs.LG
- [ ] open a PR against [`tools/MassGen`](../../../tools/MassGen/) exposing the evaluation as a skill; draft already committed under [`massgen_skill_draft/`](../massgen_skill_draft/)
- [ ] submit PR to [`projects/cellforge-agents`](../../cellforge-agents/) for the preflight CLI hook
- Scope: what we can ship today, revisions or not.

### 4.2 *Nature Methods* Brief Communications (after §1, §2 revisions)

- [ ] 3-page Brief Communications draft using the supplement §5 numbers
- [ ] Single headline figure: three-panel (E3 / E3-Adamson / E3b) with regret curves
- [ ] Supplementary = current SUPPLEMENT.md
- Target: 6–8 week review cycle, revisions likely

### 4.3 ICLR 2027 Agent workshop (after §1, §2, §3 revisions)

- [ ] 8-page short paper emphasising the contextual-BO framing and γ_T analysis
- [ ] Required: real trace collection (MC3(b)) — ML audience won't accept simulated probes

## 5. Proposed repository organization for publication

The current layout is monorepo-ish. For the public release, split into two artifacts:

### 5.1 Public repo — `perturb-seq-eval`

```
perturb-seq-eval/
├── README.md                    ← 1-page overview + pip install + example
├── pyproject.toml               ← already Poetry-packaged
├── LICENSE                      ← Apache-2.0
├── CITATION.cff                 ← ADD
├── docs/
│   ├── THESIS.md
│   ├── DESIGN.md
│   ├── SUPPLEMENT_DESIGN.md
│   ├── SUPPLEMENT.md            ← reviewer-facing reproduction doc
│   ├── REVIEWER_CRITIQUE.md     ← transparency — "here's what we know is weak"
│   ├── PUBLICATION_CHECKLIST.md ← this file
│   └── figures/                 ← symlink or copy of artifacts/modal_run/figures/
├── src/perturb_eval/            ← library code
├── tests/                       ← 92 unit tests
├── scripts/
│   ├── fetch_adamson.py         ← one-command data download
│   ├── modal/app.py             ← Modal reproduction entrypoint
│   └── local/                   ← CPU-only debug + render scripts
├── paper/                       ← LaTeX for Brief Communications draft
└── artifacts/
    └── modal_run/               ← frozen artifacts snapshot (JSON/JSONL + PNG/PDF/HTML)
```

ADD at repo root:

- [ ] `CITATION.cff` with BibTeX entries for THESIS + SUPPLEMENT + upstream refs (Snell, Archon, Krause–Ong, Cui-scGPT, Lotfollahi-CPA, Roohani-GEARS, Adamson)
- [ ] `CHANGELOG.md` tracking the deviation log from SUPPLEMENT.md §9
- [ ] `.github/workflows/tests.yml` running pytest on PRs (CI already green locally; just wire it)
- [ ] `CONTRIBUTING.md` pointing at the metric-drop and optimizer-addition extension points
- [ ] `README.md` upgrade to lead with the three-regime plot and the "what does this reproduce" verification ladder

### 5.2 Data repo — `perturb-seq-eval-artifacts`

The `artifacts/modal_run/` tree is 22 MB of figures + 272 KB of JSON. Two options:

- **Zenodo DOI**. Upload the `modal_run/` tree to Zenodo with a DOI. Link from README.md + CITATION.cff. Standard for bio supplements. Required if we want the data citable from the paper.
- **git-lfs**. Keep artifacts in the repo under git-lfs. Simpler for reviewers but bloats clones.

Recommendation: **Zenodo DOI** for final artefacts; `artifacts/modal_run/` becomes a git-lfs-tracked mirror so the `jq`-it-yourself workflow still works from the git clone.

### 5.3 What to prune before making the repo public

- `artifacts/dry_run/` — supersceded by `modal_run/`. Either archive or delete.
- `paper/paper.aux`, `paper/paper.log`, `paper/paper.bbl`, `paper/paper.blg`, `paper/paper.out` — LaTeX build artefacts; add to `.gitignore` and remove from tracked history.
- `.ruff_cache/`, `.pytest_cache/`, `__pycache__/` — already-gitignored most places; audit.
- `massgen_skill_draft/` — keep, it's shipped intentionally.

## 6. Pre-submission checklist (final sweep)

| Item | Status |
|---|---|
| 92/92 pytest green | ✅ |
| `poetry build` clean wheel | ✅ |
| `modal deploy … && modal run … --step all` reproduces every number | ✅ |
| Adamson SHA-256 recorded in README | ⬜ |
| Zenodo DOI minted for artifacts | ⬜ |
| `CITATION.cff` with BibTeX for every cited paper | ⬜ |
| Figures render inline in GitHub markdown | ✅ (now PNG) |
| No TODO / FIXME / XXX in shipped code | ⬜ audit |
| License headers in every source file | ⬜ audit |
| `pip install perturb-eval` works on a clean venv | ⬜ |
| Regret/CI revision (MC1) | ⬜ |
| Backbone-tie reframe (MC2) | ⬜ |
| Probe disclosure or real traces (MC3) | ⬜ |
| CHANGELOG entry for this supplement run | ⬜ |
| README quick-start command renders on GitHub | ⬜ |

## 7. Estimated time to submission-ready

- With only MC1 + MC2 + MC3(a) done: **2 engineer-days + $1 Modal** → bioRxiv preprint ready, Brief Communications draft startable.
- With MC1–MC4 + mc5 + mc10 + MC3(b) (real traces): **5 engineer-days + $12 Modal** → ICLR-workshop-ready short paper.

Either path fits inside the remaining Hackathon budget.
